/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ferreteria.dao;

import com.login.lib.Registro;
import com.login.lib.Registro2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author edwin
 */
public class Conexion {
   
    String bd = "ferreteria_mirna_perez";  // se declara la variable bd y se ingresa el nombre de la BD
    String url = "jdbc:mysql://localhost:3306/";    //Se declara la variable url y se ingresa la localizacion de la BD
    String user = "root"; 
    String password = "";
    String driver = "com.mysql.cj.jdbc.Driver";
    Connection cx;

    public Conexion(String bd) {
        this.bd = bd;
    }

    public Connection conectar (){
    
        try {
            Class.forName(driver);
            cx =DriverManager.getConnection(url + bd, user, password);
            System.out.println("se conecto a la BD " + bd);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("no se conecto a la BD " + bd);
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }
    
   
    public void agregar() {      
        Connection conexion = null;
        Registro r = new Registro();
        
        
        
       try{
           
           
           Class.forName(driver);
           conexion = DriverManager.getConnection(url + bd  ,user, password);
           
        String sql = "INSERT INTO `administrador` (`id`, `usuario`, `contraseña`, `correo`, `telefono`) VALUES (NULL, '"+" " +"', '"+ ""+"', 'edw@gmail.com', '89569717');";
            Statement statement = conexion.createStatement();
            statement.execute(sql);
        
       }catch(Exception ex){
       Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
       }
    } 
   
    
        
       
    
    
  
    
    public void desconectar(){
        try {
            cx.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public static void main(String[] args){
        
            Conexion Conexion = new Conexion("ferreteria_mirna_perez");
            Conexion.conectar();
        
        }
  
    
   
}