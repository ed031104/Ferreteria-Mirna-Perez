/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.login;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Event;
import javax.swing.JFrame;

public class Login extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public Login() {
        initComponents();
       
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        separador2 = new javax.swing.JPanel();
        exitBtn = new javax.swing.JPanel();
        exitTxt = new javax.swing.JLabel();
        Header = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        Nempresa = new javax.swing.JLabel();
        imgfondo = new javax.swing.JLabel();
        logo2 = new javax.swing.JLabel();
        txtIS = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JLabel();
        NombreU = new javax.swing.JTextField();
        separador = new javax.swing.JSeparator();
        txtContraseña1 = new javax.swing.JLabel();
        ContraseñaU = new javax.swing.JPasswordField();
        separador1 = new javax.swing.JSeparator();
        loginBtn = new javax.swing.JPanel();
        loginBtn1 = new javax.swing.JLabel();
        Olvidotxt = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        separador2.setBackground(new java.awt.Color(255, 255, 255));
        separador2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        separador2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exitBtn.setBackground(new java.awt.Color(255, 255, 255));

        exitTxt.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        exitTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitTxt.setText("X");
        exitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitTxt.setPreferredSize(new java.awt.Dimension(40, 40));
        exitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout exitBtnLayout = new javax.swing.GroupLayout(exitBtn);
        exitBtn.setLayout(exitBtnLayout);
        exitBtnLayout.setHorizontalGroup(
            exitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );
        exitBtnLayout.setVerticalGroup(
            exitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        separador2.add(exitBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 30));

        Header.setBackground(new java.awt.Color(255, 255, 255));
        Header.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Header.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                HeaderMouseDragged(evt);
            }
        });
        Header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                HeaderMousePressed(evt);
            }
        });

        javax.swing.GroupLayout HeaderLayout = new javax.swing.GroupLayout(Header);
        Header.setLayout(HeaderLayout);
        HeaderLayout.setHorizontalGroup(
            HeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        HeaderLayout.setVerticalGroup(
            HeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        separador2.add(Header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 20));

        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Captura de pantalla 2023-04-26 173612.png"))); // NOI18N
        separador2.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 110, 360, 120));

        Nempresa.setBackground(new java.awt.Color(255, 255, 255));
        Nempresa.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        Nempresa.setForeground(new java.awt.Color(255, 255, 255));
        Nempresa.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Nempresa.setText("FERRETERIA MIRNA PEREZ");
        separador2.add(Nempresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 260, 360, -1));

        imgfondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Sin título-1.png"))); // NOI18N
        imgfondo.setText("jLabel1");
        separador2.add(imgfondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 10, 360, 500));

        logo2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        logo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Captura de pantalla 2023-04-26 185356.png"))); // NOI18N
        logo2.setText("FERRETERIA");
        separador2.add(logo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 280, -1));

        txtIS.setFont(new java.awt.Font("Segoe UI Semibold", 0, 24)); // NOI18N
        txtIS.setText("INICIAR SECCION");
        separador2.add(txtIS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 220, -1));

        txtUsuario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtUsuario.setText("USUARIO");
        separador2.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        NombreU.setForeground(new java.awt.Color(204, 204, 204));
        NombreU.setText("Ingrese su nombre de usuario");
        NombreU.setBorder(null);
        NombreU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                NombreUMousePressed(evt);
            }
        });
        NombreU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreUActionPerformed(evt);
            }
        });
        separador2.add(NombreU, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 340, 30));

        separador.setForeground(new java.awt.Color(0, 0, 0));
        separador2.add(separador, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 273, 340, 10));

        txtContraseña1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtContraseña1.setText("CONTRASEÑA");
        separador2.add(txtContraseña1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        ContraseñaU.setForeground(new java.awt.Color(204, 204, 204));
        ContraseñaU.setText("********");
        ContraseñaU.setBorder(null);
        ContraseñaU.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ContraseñaUMousePressed(evt);
            }
        });
        ContraseñaU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContraseñaUActionPerformed(evt);
            }
        });
        separador2.add(ContraseñaU, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 340, 30));

        separador1.setForeground(new java.awt.Color(0, 0, 0));
        separador2.add(separador1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 340, 10));

        loginBtn.setBackground(new java.awt.Color(51, 153, 255));

        loginBtn1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        loginBtn1.setForeground(new java.awt.Color(255, 255, 255));
        loginBtn1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loginBtn1.setText("INGRESAR");
        loginBtn1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        loginBtn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                loginBtn1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginBtn1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginBtn1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout loginBtnLayout = new javax.swing.GroupLayout(loginBtn);
        loginBtn.setLayout(loginBtnLayout);
        loginBtnLayout.setHorizontalGroup(
            loginBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 140, Short.MAX_VALUE)
            .addGroup(loginBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(loginBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
        );
        loginBtnLayout.setVerticalGroup(
            loginBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
            .addGroup(loginBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(loginBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
        );

        separador2.add(loginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 140, 30));

        Olvidotxt.setFont(new java.awt.Font("Roboto Light", 0, 12)); // NOI18N
        Olvidotxt.setForeground(new java.awt.Color(0, 51, 255));
        Olvidotxt.setText("¿Olvido su contraseña?");
        Olvidotxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Olvidotxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                OlvidotxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                OlvidotxtMouseExited(evt);
            }
        });
        separador2.add(Olvidotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REGISTRARSE");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        separador2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 430, 140, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(separador2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(separador2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void NombreUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreUActionPerformed

    private void ContraseñaUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContraseñaUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContraseñaUActionPerformed

    private void HeaderMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HeaderMousePressed
       xMouse = evt.getX();
       yMouse = evt.getY();
    }//GEN-LAST:event_HeaderMousePressed

    private void HeaderMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HeaderMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_HeaderMouseDragged

    private void exitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitTxtMouseClicked

    private void exitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseEntered
        exitBtn.setBackground(Color.red);
        exitTxt.setForeground(Color.white);
    }//GEN-LAST:event_exitTxtMouseEntered

    private void exitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseExited
        exitBtn.setBackground(Color.white);
        exitTxt.setForeground(Color.black);
    }//GEN-LAST:event_exitTxtMouseExited

    private void loginBtn1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginBtn1MouseEntered
        loginBtn.setBackground(new Color(1, 123, 196));
    }//GEN-LAST:event_loginBtn1MouseEntered

    private void loginBtn1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginBtn1MouseExited
        loginBtn.setBackground(new Color(51,153,255));
    }//GEN-LAST:event_loginBtn1MouseExited

    private void NombreUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NombreUMousePressed
       if(NombreU.getText().equals("Ingrese su nombre de usuario")){
        NombreU.setText("");
        NombreU.setForeground(Color.black);
       }
       if (String.valueOf(ContraseñaU.getPassword()).isEmpty()){
            ContraseñaU.setText("********");
            ContraseñaU.setForeground(Color.gray);
       }
    }//GEN-LAST:event_NombreUMousePressed

    private void ContraseñaUMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContraseñaUMousePressed
      if(String.valueOf(ContraseñaU.getPassword()).equals("********")){
        ContraseñaU.setText("");
        ContraseñaU.setForeground(Color.black);
      }
      if(NombreU.getText().isEmpty()){
        NombreU.setText("Ingrese su nombre de usuario");
        NombreU.setForeground(Color.gray);
      }
    }//GEN-LAST:event_ContraseñaUMousePressed

    private void loginBtn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginBtn1MouseClicked
        javax.swing.JOptionPane.showMessageDialog(this, "Intento de login con los datos:\nUsuario: " + NombreU.getText() + "\nContraseña: " + String.valueOf(ContraseñaU.getPassword()) ,"LOGIN",javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
        Login l = new Login();
        Menu M = new Menu();
        M.setVisible(true);
        
        
        
         
    }//GEN-LAST:event_loginBtn1MouseClicked

    private void OlvidotxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OlvidotxtMouseEntered
        Olvidotxt.setForeground(new Color(0, 0, 51, 255));
    }//GEN-LAST:event_OlvidotxtMouseEntered

    private void OlvidotxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OlvidotxtMouseExited
        Olvidotxt.setForeground(new Color(0,51,255));
    }//GEN-LAST:event_OlvidotxtMouseExited

    private void jLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseEntered
        jPanel1.setBackground(new Color(1, 123, 196));
    }//GEN-LAST:event_jLabel1MouseEntered

    private void jLabel1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseExited
        jPanel1.setBackground(new Color(51,153,255));
    }//GEN-LAST:event_jLabel1MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField ContraseñaU;
    private javax.swing.JPanel Header;
    private javax.swing.JLabel Nempresa;
    private javax.swing.JTextField NombreU;
    private javax.swing.JLabel Olvidotxt;
    private javax.swing.JPanel exitBtn;
    private javax.swing.JLabel exitTxt;
    private javax.swing.JLabel imgfondo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel loginBtn;
    private javax.swing.JLabel loginBtn1;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo2;
    private javax.swing.JSeparator separador;
    private javax.swing.JSeparator separador1;
    private javax.swing.JPanel separador2;
    private javax.swing.JLabel txtContraseña1;
    private javax.swing.JLabel txtIS;
    private javax.swing.JLabel txtUsuario;
    // End of variables declaration//GEN-END:variables
}
